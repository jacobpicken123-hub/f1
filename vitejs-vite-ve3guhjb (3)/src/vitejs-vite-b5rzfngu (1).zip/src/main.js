import "./style.css";

import { initialRaces } from "./sampleData.js";


/* Persistable copy */
const STORAGE_KEY = "f1_demo_races_v1";
let races = loadRaces();

/* active race index (0-based) */
let activeIndex = 0;

/* --- helpers --- */
function loadRaces(){
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if(raw){
      return JSON.parse(raw);
    }
  } catch(e){}
  // deep copy initialRaces to avoid mutating module data
  return initialRaces.map(r => ({ ...r, results: r.results.map(x => ({...x})) }));
}

function saveRaces(){
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(races)); } catch(e){}
}

/* --- build UI --- */
const app = document.getElementById("app");
app.innerHTML = `
  <div class="container">
    <div class="header">
      <div class="brand">
        <div class="logo">F1</div>
        <div class="title">F1 — Race Results (Demo)</div>
      </div>

      <div class="controls">
        <div class="pager">
          <button id="prevBtn" class="btn">&lt; Prev</button>
          <select id="raceSelect" class="select-race"></select>
          <button id="nextBtn" class="btn">Next &gt;</button>
        </div>
        <button id="resetBtn" class="btn" title="Reset demo data">Reset</button>
      </div>
    </div>

    <div id="tabWrap" class="race-tabs"></div>

    <div class="table-card">
      <h2 id="raceTitle">Race</h2>
      <table class="standings" aria-describedby="raceTitle">
        <thead>
          <tr>
            <th class="pos">#</th>
            <th>Driver</th>
            <th>Team</th>
            <th class="points">Points</th>
          </tr>
        </thead>
        <tbody id="resultsBody"></tbody>
      </table>

      <div>
        <h3>Add result to this race</h3>
        <form id="addForm" class="add-form">
          <input id="nameInput" type="text" placeholder="Driver name" required />
          <input id="teamInput" type="text" placeholder="Team" required />
          <input id="pointsInput" type="number" placeholder="Points" required />
          <button class="btn" type="submit">Add</button>
        </form>
      </div>
    </div>

    <div class="footer">This is a demo inspired UI. Data is persisted to localStorage.</div>
  </div>
`;

/* --- DOM references --- */
const raceSelect = document.getElementById("raceSelect");
const tabWrap = document.getElementById("tabWrap");
const resultsBody = document.getElementById("resultsBody");
const raceTitle = document.getElementById("raceTitle");
const prevBtn = document.getElementById("prevBtn");
const nextBtn = document.getElementById("nextBtn");
const resetBtn = document.getElementById("resetBtn");
const addForm = document.getElementById("addForm");

/* --- render functions --- */
function populateRaceSelect(){
  raceSelect.innerHTML = races.map((r, i) => `<option value="${i}">${r.name}</option>`).join("");
  raceSelect.value = activeIndex;
}

function renderTabs(){
  tabWrap.innerHTML = races.map((r, i) => {
    const active = i === activeIndex ? "active" : "";
    return `<div class="tab ${active}" data-i="${i}">${r.name}</div>`;
  }).join("");
  // attach click handlers to tabs
  tabWrap.querySelectorAll(".tab").forEach(el=>{
    el.onclick = () => {
      activeIndex = Number(el.getAttribute("data-i"));
      updateUI();
    }
  });
}

function renderResults(){
  const race = races[activeIndex];
  raceTitle.textContent = race.name;
  resultsBody.innerHTML = race.results
    .sort((a,b)=> (a.pos ?? 999) - (b.pos ?? 999))
    .map(r => `
      <tr>
        <td class="pos">${r.pos ?? "-"}</td>
        <td>${escapeHtml(r.name)}</td>
        <td>${escapeHtml(r.team)}</td>
        <td class="points">${r.points ?? 0}</td>
      </tr>`).join("");
}

function updateUI(){
  populateRaceSelect();
  renderTabs();
  renderResults();
  // disable prev/next if at ends
  prevBtn.disabled = activeIndex === 0;
  nextBtn.disabled = activeIndex === races.length - 1;
  saveRaces();
}

/* --- events --- */
raceSelect.addEventListener("change", (e)=>{
  activeIndex = Number(e.target.value);
  updateUI();
});

prevBtn.addEventListener("click", ()=>{
  if(activeIndex>0){ activeIndex--; updateUI(); }
});
nextBtn.addEventListener("click", ()=>{
  if(activeIndex < races.length -1){ activeIndex++; updateUI(); }
});

resetBtn.addEventListener("click", ()=>{
  if(confirm("Reset demo data to original sample? This will clear local edits.")){
    localStorage.removeItem(STORAGE_KEY);
    races = loadRaces();
    activeIndex = 0;
    updateUI();
  }
});

addForm.addEventListener("submit", (e)=>{
  e.preventDefault();
  const name = document.getElementById("nameInput").value.trim();
  const team = document.getElementById("teamInput").value.trim();
  const points = parseInt(document.getElementById("pointsInput").value || "0", 10);

  if(!name || !team){ return alert("Please fill name and team"); }

  // append to the current race results
  const race = races[activeIndex];
  const nextPos = (race.results.length ? Math.max(...race.results.map(r=>r.pos||0)) : 0) + 1;
  race.results.push({ pos: nextPos, name, team, points });

  // re-render & persist
  updateUI();

  // clear form
  e.target.reset();
});

/* small helper: escape HTML */
function escapeHtml(s){
  return String(s).replace(/[&<>"']/g, (m) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
}

/* Initial render */
updateUI();
